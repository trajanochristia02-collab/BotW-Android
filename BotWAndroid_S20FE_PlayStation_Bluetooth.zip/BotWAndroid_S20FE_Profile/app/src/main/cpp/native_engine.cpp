#include <jni.h>
#include <vulkan/vulkan.h>
#include <string>
#include <vector>

extern "C"
JNIEXPORT jstring JNICALL
Java_com_botw_android_MainActivity_nativeGetVulkanInfo(
        JNIEnv* env, jobject) {
    VkApplicationInfo appInfo{};
    appInfo.sType = VK_STRUCTURE_TYPE_APPLICATION_INFO;
    appInfo.pApplicationName = "BotWAndroid";
    appInfo.applicationVersion = VK_MAKE_VERSION(0, 2, 0);
    appInfo.pEngineName = "BotWAndroid Native Runtime";
    appInfo.engineVersion = VK_MAKE_VERSION(0, 2, 0);
    appInfo.apiVersion = VK_API_VERSION_1_0;

    VkInstanceCreateInfo createInfo{};
    createInfo.sType = VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO;
    createInfo.pApplicationInfo = &appInfo;

    VkInstance instance = VK_NULL_HANDLE;
    VkResult result = vkCreateInstance(&createInfo, nullptr, &instance);
    if (result != VK_SUCCESS) {
        return env->NewStringUTF(
            ("Falha ao criar instancia Vulkan. VkResult=" +
             std::to_string(static_cast<int>(result))).c_str());
    }

    uint32_t count = 0;
    result = vkEnumeratePhysicalDevices(instance, &count, nullptr);
    if (result != VK_SUCCESS || count == 0) {
        vkDestroyInstance(instance, nullptr);
        return env->NewStringUTF("Nenhum dispositivo Vulkan encontrado.");
    }

    std::vector<VkPhysicalDevice> devices(count);
    result = vkEnumeratePhysicalDevices(instance, &count, devices.data());
    if (result != VK_SUCCESS) {
        vkDestroyInstance(instance, nullptr);
        return env->NewStringUTF("Falha ao enumerar dispositivos Vulkan.");
    }

    VkPhysicalDeviceProperties props{};
    vkGetPhysicalDeviceProperties(devices[0], &props);
    std::string out = "Vulkan inicializado\\nGPU: ";
    out += props.deviceName;
    out += "\\nVulkan API: ";
    out += std::to_string(VK_VERSION_MAJOR(props.apiVersion)) + "." +
           std::to_string(VK_VERSION_MINOR(props.apiVersion)) + "." +
           std::to_string(VK_VERSION_PATCH(props.apiVersion));
    vkDestroyInstance(instance, nullptr);
    return env->NewStringUTF(out.c_str());
}
