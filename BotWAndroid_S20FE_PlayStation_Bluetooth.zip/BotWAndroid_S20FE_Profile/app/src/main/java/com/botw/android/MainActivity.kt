package com.botw.android

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import com.botw.android.performance.S20Profile
import java.util.Locale

class MainActivity : Activity() {
    companion object {
        init { System.loadLibrary("botw_native") }
    }

    private external fun nativeGetVulkanInfo(): String
    private lateinit var controllerStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY

        val profile = S20Profile.detect()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 32, 32, 32)
            setBackgroundColor(Color.rgb(20, 27, 38))
        }

        fun label(text: String, size: Float, color: Int) = TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 8)
        }

        root.addView(label("BotWAndroid", 30f, Color.WHITE))
        root.addView(label("Perfil de desempenho: ${profile.deviceFamily}", 18f,
            Color.rgb(100, 230, 150)))
        root.addView(label("Meta: ${profile.targetFps} FPS", 17f, Color.WHITE))
        root.addView(label("Escala configurada: ${profile.resolutionScale}x", 17f,
            Color.WHITE))
        root.addView(label(profile.notes, 14f, Color.LTGRAY))

        val vulkanText = try {
            nativeGetVulkanInfo().replace("\\n", "\n")
        } catch (e: UnsatisfiedLinkError) {
            "Biblioteca nativa não carregada: ${e.message}"
        }
        root.addView(label(vulkanText, 15f, Color.WHITE))
        controllerStatus = label("Controle: aguardando entrada. Conecte o DualShock 4 ou DualSense por Bluetooth.", 15f, Color.rgb(120, 200, 255))
        root.addView(controllerStatus)
        setContentView(root)
    }

    // Os controles Bluetooth do PlayStation enviam eventos padrão do Android.
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (isGameController(event)) {
            val device = event.device?.name ?: "Controle Bluetooth"
            val action = if (event.action == KeyEvent.ACTION_DOWN) "pressionado" else "solto"
            val button = buttonName(event.keyCode)
            controllerStatus.text = "$device\nBotão: $button ($action)"
            // A base apenas testa e exibe os eventos; o motor do jogo ainda precisa ser integrado.
            if (event.keyCode != KeyEvent.KEYCODE_BACK) return true
        }
        return super.dispatchKeyEvent(event)
    }

    override fun dispatchGenericMotionEvent(event: MotionEvent): Boolean {
        if (isGameController(event) && event.action == MotionEvent.ACTION_MOVE) {
            val device = event.device?.name ?: "Controle Bluetooth"
            val lx = axis(event, MotionEvent.AXIS_X)
            val ly = axis(event, MotionEvent.AXIS_Y)
            val rx = axis(event, MotionEvent.AXIS_RX, MotionEvent.AXIS_Z)
            val ry = axis(event, MotionEvent.AXIS_RY, MotionEvent.AXIS_RZ)
            controllerStatus.text = String.format(
                Locale.US,
                "%s\nAnalógico esquerdo: X %.2f / Y %.2f\nAnalógico direito: X %.2f / Y %.2f",
                device, lx, ly, rx, ry
            )
            return true
        }
        return super.dispatchGenericMotionEvent(event)
    }

    private fun isGameController(event: KeyEvent): Boolean {
        val source = event.source
        return source and InputDevice.SOURCE_GAMEPAD == InputDevice.SOURCE_GAMEPAD ||
            source and InputDevice.SOURCE_DPAD == InputDevice.SOURCE_DPAD
    }

    private fun isGameController(event: MotionEvent): Boolean {
        val source = event.source
        return source and InputDevice.SOURCE_JOYSTICK == InputDevice.SOURCE_JOYSTICK ||
            source and InputDevice.SOURCE_GAMEPAD == InputDevice.SOURCE_GAMEPAD
    }

    private fun axis(event: MotionEvent, primary: Int, fallback: Int = primary): Float {
        val value = event.getAxisValue(primary)
        return if (value != 0f) value else event.getAxisValue(fallback)
    }

    private fun buttonName(code: Int): String = when (code) {
        KeyEvent.KEYCODE_BUTTON_A -> "A / cruz (varia por controle)"
        KeyEvent.KEYCODE_BUTTON_B -> "B / círculo (varia por controle)"
        KeyEvent.KEYCODE_BUTTON_X -> "X / quadrado (varia por controle)"
        KeyEvent.KEYCODE_BUTTON_Y -> "Y / triângulo (varia por controle)"
        KeyEvent.KEYCODE_BUTTON_L1 -> "L1"
        KeyEvent.KEYCODE_BUTTON_R1 -> "R1"
        KeyEvent.KEYCODE_BUTTON_L2 -> "L2"
        KeyEvent.KEYCODE_BUTTON_R2 -> "R2"
        KeyEvent.KEYCODE_BUTTON_START -> "Options / Start"
        KeyEvent.KEYCODE_BUTTON_SELECT -> "Create / Select"
        KeyEvent.KEYCODE_BUTTON_THUMBL -> "L3"
        KeyEvent.KEYCODE_BUTTON_THUMBR -> "R3"
        KeyEvent.KEYCODE_DPAD_UP -> "Direcional para cima"
        KeyEvent.KEYCODE_DPAD_DOWN -> "Direcional para baixo"
        KeyEvent.KEYCODE_DPAD_LEFT -> "Direcional para esquerda"
        KeyEvent.KEYCODE_DPAD_RIGHT -> "Direcional para direita"
        else -> "código $code"
    }
}
