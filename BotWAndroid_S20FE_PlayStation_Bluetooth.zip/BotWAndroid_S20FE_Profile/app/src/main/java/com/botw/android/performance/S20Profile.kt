package com.botw.android.performance

import android.os.Build

data class PerformanceProfile(
    val deviceFamily: String,
    val targetFps: Int,
    val resolutionScale: Float,
    val notes: String
)

object S20Profile {
    fun detect(): PerformanceProfile {
        val model = Build.MODEL.lowercase()
        val device = (Build.DEVICE + " " + Build.PRODUCT).lowercase()
        val isS20Fe = model.contains("s20 fe") ||
            model.contains("sm-g780") || model.contains("sm-g781") ||
            device.contains("r8q") || device.contains("r9q")

        return if (isS20Fe) {
            PerformanceProfile(
                deviceFamily = "Galaxy S20 FE",
                targetFps = 30,
                resolutionScale = 0.75f,
                notes = "Perfil experimental. Escala ainda não aplicada ao renderizador."
            )
        } else {
            PerformanceProfile(
                deviceFamily = "Android não identificado",
                targetFps = 30,
                resolutionScale = 1.0f,
                notes = "Perfil genérico; teste em aparelho real necessário."
            )
        }
    }
}
