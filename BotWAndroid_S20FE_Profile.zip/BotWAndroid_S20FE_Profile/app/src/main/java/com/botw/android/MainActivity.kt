package com.botw.android

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import com.botw.android.performance.S20Profile

class MainActivity : Activity() {
    companion object {
        init { System.loadLibrary("botw_native") }
    }

    private external fun nativeGetVulkanInfo(): String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY

        val profile = S20Profile.detect()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 32, 32, 32)
            setBackgroundColor(Color.rgb(20, 27, 38))
        }

        fun label(text: String, size: Float, color: Int) = TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 8)
        }

        root.addView(label("BotWAndroid", 30f, Color.WHITE))
        root.addView(label("Perfil de desempenho: ${profile.deviceFamily}", 18f,
            Color.rgb(100, 230, 150)))
        root.addView(label("Meta: ${profile.targetFps} FPS", 17f, Color.WHITE))
        root.addView(label("Escala configurada: ${profile.resolutionScale}x", 17f,
            Color.WHITE))
        root.addView(label(profile.notes, 14f, Color.LTGRAY))

        val vulkanText = try {
            nativeGetVulkanInfo()
        } catch (e: UnsatisfiedLinkError) {
            "Biblioteca nativa não carregada: ${e.message}"
        }
        root.addView(label(vulkanText, 15f, Color.WHITE))
        setContentView(root)
    }
}
